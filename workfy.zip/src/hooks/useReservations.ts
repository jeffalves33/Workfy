import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

export function useCreateReservation() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (input: {
      space_id: string;
      start_at: string;
      end_at: string;
      subtotal_cents: number;
      platform_fee_cents: number;
      total_cents: number;
      attendees_count?: number;
      notes?: string;
    }) => {
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('reservations')
        .insert({
          space_id: input.space_id,
          tenant_user_id: user.id,
          start_at: input.start_at,
          end_at: input.end_at,
          subtotal_cents: input.subtotal_cents,
          platform_fee_cents: input.platform_fee_cents,
          total_cents: input.total_cents,
          attendees_count: input.attendees_count || 1,
          notes: input.notes || null,
        })
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reservations'] });
    },
  });
}

export function useMyReservations() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['reservations', 'mine', user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('reservations')
        .select(`
          *,
          space:spaces(
            id, title, type, base_price_cents,
            venue:venues(city, state, address_line),
            photos:space_photos(url, sort_order)
          )
        `)
        .eq('tenant_user_id', user!.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
  });
}
